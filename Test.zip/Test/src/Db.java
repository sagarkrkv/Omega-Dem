import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;

import org.codehaus.jackson.map.ObjectMapper;

public class Db {
	public static <T> void main(String args[]) throws IOException {
		ArrayList<String> list = new ArrayList<>();
		Map<String, ArrayList<String>> map = new LinkedHashMap<>();
		BufferedReader in = new BufferedReader(new FileReader("text.txt"));
		String line = "";

		while ((line = in.readLine()) != null) {
			line = line.trim();
			StringTokenizer st = new StringTokenizer(line, " ");
			String key = st.nextToken();
			list.add(st.nextToken());
			list.add(st.nextToken());
			list.add(st.nextToken());
			list.add(st.nextToken());

			ArrayList<List<T>> parts = new ArrayList<List<T>>();

			for (int i = 0; i < list.size(); i += 4) {
				parts.add(new ArrayList<T>((Collection<? extends T>) list.subList(i, Math.min(list.size(), i + 4))));

			}
			for (List<T> p : parts) {
				map.put(key, (ArrayList<String>) p);
			}
		}

		
		String mapAsJson = new ObjectMapper().writeValueAsString(map);
		System.out.println(mapAsJson);
		
	}

}
